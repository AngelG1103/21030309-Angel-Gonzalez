﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace login.clases
{
   public static class GLOBALES
    {
        static public string dbn = "Checador";

        static public string server = @"ANGEL\SQLEXPRESS";

        static public string Password = "1234";

        static public string seguridad = "Integrated Security=True";

        static public string UserID = "sa";

        static public string miconexion = @"Data Source = " + server + "; Initial Catalog = " + dbn + "; Persist Security Info = True; User ID = sa; Password = " + Password;
    }
}
