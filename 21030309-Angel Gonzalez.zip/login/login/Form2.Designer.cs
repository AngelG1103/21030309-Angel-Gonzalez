﻿
namespace login
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cATALOGOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uSUARIOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rOLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mODULOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gENERALESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mOVIMIENTOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEPORTESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uTILERIASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sALIRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cATALOGOToolStripMenuItem,
            this.mOVIMIENTOSToolStripMenuItem,
            this.rEPORTESToolStripMenuItem,
            this.uTILERIASToolStripMenuItem,
            this.sALIRToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(716, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cATALOGOToolStripMenuItem
            // 
            this.cATALOGOToolStripMenuItem.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.cATALOGOToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uSUARIOSToolStripMenuItem,
            this.rOLToolStripMenuItem,
            this.mODULOToolStripMenuItem,
            this.gENERALESToolStripMenuItem});
            this.cATALOGOToolStripMenuItem.Name = "cATALOGOToolStripMenuItem";
            this.cATALOGOToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.cATALOGOToolStripMenuItem.Text = "CATALOGO";
            // 
            // uSUARIOSToolStripMenuItem
            // 
            this.uSUARIOSToolStripMenuItem.Name = "uSUARIOSToolStripMenuItem";
            this.uSUARIOSToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.uSUARIOSToolStripMenuItem.Text = "USUARIOS";
            this.uSUARIOSToolStripMenuItem.Click += new System.EventHandler(this.uSUARIOSToolStripMenuItem_Click);
            // 
            // rOLToolStripMenuItem
            // 
            this.rOLToolStripMenuItem.Name = "rOLToolStripMenuItem";
            this.rOLToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.rOLToolStripMenuItem.Text = "ROL";
            this.rOLToolStripMenuItem.Click += new System.EventHandler(this.rOLToolStripMenuItem_Click);
            // 
            // mODULOToolStripMenuItem
            // 
            this.mODULOToolStripMenuItem.Name = "mODULOToolStripMenuItem";
            this.mODULOToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.mODULOToolStripMenuItem.Text = "MODULO";
            this.mODULOToolStripMenuItem.Click += new System.EventHandler(this.mODULOToolStripMenuItem_Click);
            // 
            // gENERALESToolStripMenuItem
            // 
            this.gENERALESToolStripMenuItem.Name = "gENERALESToolStripMenuItem";
            this.gENERALESToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.gENERALESToolStripMenuItem.Text = "GENERALES";
            this.gENERALESToolStripMenuItem.Click += new System.EventHandler(this.gENERALESToolStripMenuItem_Click);
            // 
            // mOVIMIENTOSToolStripMenuItem
            // 
            this.mOVIMIENTOSToolStripMenuItem.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.mOVIMIENTOSToolStripMenuItem.Name = "mOVIMIENTOSToolStripMenuItem";
            this.mOVIMIENTOSToolStripMenuItem.Size = new System.Drawing.Size(98, 20);
            this.mOVIMIENTOSToolStripMenuItem.Text = "MOVIMIENTOS";
            // 
            // rEPORTESToolStripMenuItem
            // 
            this.rEPORTESToolStripMenuItem.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.rEPORTESToolStripMenuItem.Name = "rEPORTESToolStripMenuItem";
            this.rEPORTESToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.rEPORTESToolStripMenuItem.Text = "REPORTES";
            // 
            // uTILERIASToolStripMenuItem
            // 
            this.uTILERIASToolStripMenuItem.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.uTILERIASToolStripMenuItem.Name = "uTILERIASToolStripMenuItem";
            this.uTILERIASToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.uTILERIASToolStripMenuItem.Text = "UTILERIAS";
            // 
            // sALIRToolStripMenuItem
            // 
            this.sALIRToolStripMenuItem.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.sALIRToolStripMenuItem.Name = "sALIRToolStripMenuItem";
            this.sALIRToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.sALIRToolStripMenuItem.Text = "SALIR";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(716, 366);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cATALOGOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mOVIMIENTOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEPORTESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uTILERIASToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sALIRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uSUARIOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rOLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mODULOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gENERALESToolStripMenuItem;
    }
}